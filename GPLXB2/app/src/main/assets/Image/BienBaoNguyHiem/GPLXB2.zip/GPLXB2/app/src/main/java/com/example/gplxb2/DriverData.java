//package com.example.gplxb2;
//import java.util.List;
//
//
//public class DriverData {
//    private List<Question> question;
//    private List<String> critical; // Danh sách ID quan trọng
//
//    public List<Question> getQuestions() {
//        return question;
//    }
//
//    public List<String> getCritical() {
//        return critical;
//    }
//
//    public void setQuestions(List<Question> questions) {
//        this.question = questions;
//    }
//
//    public void setCritical(List<String> critical) {
//        this.critical = critical;
//    }
//}
