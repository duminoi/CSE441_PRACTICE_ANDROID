package com.example.gplxb2;

public class Options {
    private String A;
    private String B;
    private String C;
    private String D;
    private String E;

    public Options(String A, String B, String C, String D, String E) {
        this.A = A;
        this.B = B;
        this.C = C;
        this.D = D;
        this.E = E;
    }

    public String getA() {
        return A;
    }

    public String getB() {
        return B;
    }

    public String getC() {
        return C;
    }

    public String getD() {
        return D;
    }

    public String getE() {
        return E;
    }
}
