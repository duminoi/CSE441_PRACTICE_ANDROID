package com.example.gplxb2;

public class Image {
    private String img1;

    public Image() {
        // Constructor rỗng
    }

    public Image(String img1) {
        this.img1 = img1;
    }

    public String getImg1() {
        return img1;
    }

    public void setImg1(String img1) {
        this.img1 = img1;
    }
}
